Current Version ： 0.3   2015.12.18
1. Add websocket support

Version ： 0.2   2015.12.09
1. Use Promise to rewrite Redis.js and Mysql.js. Their interfaces have changed.
2. Add Wechat.js to support wechat sdk.
3. Add `update` method to reload js file.
4. Add some global method, such as sha1, md5, getRandomStr
5. Use pm2 to manage progress

Version ： 0.1
Initial version.